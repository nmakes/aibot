# Name: Naveen Venkat
# ID: 2015A7PS0078P

# Flag to show warnings and errors
flag_show_warnings = True
flag_show_errors = True

# Flag to show the recursion during expression evaluation. Making this true will output every intermediate step.
flag_show_expression_evaluation = False

# To clear the console after every operation
neat = True

# To print expression every time the recursive probability function (P) is called
printexpr = False